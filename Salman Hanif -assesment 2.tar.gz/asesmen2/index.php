<!DOCTYPE html>
<html>
    <head>
        <title>Rumah Makan Sunda</title>
    </head>
    <body>
    <center><h1>SELAMAT DATANG DIRUMAH MAKAN KHAS SUNDA</h1>
        <form method="post" action="prosmasuk.php">
            <table>
                <tr><td>NAMA</td><td><input type="text" name="nama"></td></tr>
                <tr><td colspan="2"><button type="submit" value="simpan">SIMPAN</button></td></tr>
            </table>
        </form>

        <p>NB* : Untuk masuk ke halaman admin silahkan ketik <i>admin</i>
        </center>
    </body>
</html>