<?php 
    $conn = new mysqli("localhost", "root", "", "as2"); 
?>
