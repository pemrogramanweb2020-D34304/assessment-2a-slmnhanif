<?php

$nama  = $_POST['nama'];

if($nama == "admin"){
    header("location:admin.php");
} else{
    header("location:masuk.php");
}



?>